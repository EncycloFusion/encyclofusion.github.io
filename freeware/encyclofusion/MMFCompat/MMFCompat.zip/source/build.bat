@echo off
setlocal
rem Batch script to build the MMF 1.x compatibility COX with clang.
rem Requires clang-cl, lld-link and llvm-rc in PATH.
rem If you want to build this COX with Visual C++ 4.x and not clang, use MMFcompat.mdp instead.

if exist extres.res del extres.res
if exist mmfcompat.obj del mmfcompat.obj
if exist MMFCompat.cox del MMFCompat.cox

llvm-rc /fo extres.res extres.rc
if errorlevel 1 exit /b 1

clang-cl --target=i686-pc-windows-msvc /nologo /c /O2 /GS- /W3 mmfcompat.c /Fo:mmfcompat.obj
if errorlevel 1 exit /b 1

lld-link /nologo /dll /machine:x86 /nodefaultlib /entry:DllMain@12 /dynamicbase:no /nxcompat:no /subsystem:windows,4.0 /base:0x69000000 /def:MMFCompat.def /out:MMFCompat.cox mmfcompat.obj extres.res
if errorlevel 1 exit /b 1

echo Built MMFCompat.cox
endlocal
