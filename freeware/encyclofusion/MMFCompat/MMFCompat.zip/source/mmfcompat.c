/*
 * MMFCompat.cox
 * Compatibility extension for Multimedia Fusion 1.x
 *
 * Fixes the legacy object-name rename corruption caused by MMF's use of
 * EM_GETLINE without adding a terminating NUL byte.
 *
 * What it does:
 * The .cox only goes into the Extensions folder.
 * The object does not need to be inserted into the CCA,
 * because being in the Extensions folder is sufficient.
 * Locates the known buggy call by a machine-code signature.
 * Validates that the call goes through USER32!SendMessageA.
 * Fails harmlessly on executables that do not match.
 *
 * The signature has been verified against the MMF 1.0 stock CD build,
 * MMF 1.5 CD build, and MMF 1.5 Build 119 to prove the fix.
 */

typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned long DWORD;
typedef unsigned int UINT;
typedef long LONG;
typedef long LPARAM;
typedef unsigned long WPARAM;
typedef long LRESULT;
typedef int BOOL;
typedef void* LPVOID;
typedef void* HINSTANCE;
typedef void* HMODULE;
typedef void* HWND;
typedef void* HMENU;
typedef void* HGLOBAL;
typedef const char* LPCSTR;
typedef char* LPSTR;
typedef unsigned short USHORT;

#define WINAPI __stdcall
#define TRUE 1
#define FALSE 0
#define DLL_PROCESS_ATTACH 1u
#define EM_GETLINE 0x00C4u
#define PAGE_READWRITE 0x04u
#define IMAGE_ORDINAL_FLAG32 0x80000000u
#define EXT_VERSION2 0x0300u
#define KGI_VERSION 0

typedef LRESULT (WINAPI *SendMessageA_t)(HWND, UINT, WPARAM, LPARAM);
typedef BOOL (WINAPI *VirtualProtect_t)(LPVOID, DWORD, DWORD, DWORD*);
typedef DWORD (WINAPI *GetModuleFileNameA_t)(HMODULE, LPSTR, DWORD);
typedef HMODULE (WINAPI *LoadLibraryA_t)(LPCSTR);

void* _ReturnAddress(void);
#pragma intrinsic(_ReturnAddress)

static HINSTANCE g_self;
static BYTE* g_host_base;
static BYTE* g_bug_return;
static SendMessageA_t g_real_SendMessageA;
static SendMessageA_t* g_send_slot;
static int g_installed;
static int g_pinned;

static BYTE* process_image_base(void) {
    BYTE* base;
    __asm {
        mov eax, fs:[0x30]
        mov eax, [eax+8]
        mov base, eax
    }
    return base;
}

static int ascii_lower(int c) {
    if (c >= 'A' && c <= 'Z') c += ('a' - 'A');
    return c;
}

static int str_ieq(const char* a, const char* b) {
    if (!a || !b) return 0;
    while (*a && *b) {
        if (ascii_lower((unsigned char)*a) != ascii_lower((unsigned char)*b)) return 0;
        ++a; ++b;
    }
    return *a == 0 && *b == 0;
}

static void copy_text(char* dst, const char* src) {
    if (!dst) return;
    if (!src) { dst[0] = 0; return; }
    while (*src) *dst++ = *src++;
    *dst = 0;
}

/* Returns the address of an IAT slot in the loaded host image. */
static void** find_iat_slot(BYTE* base, const char* wanted_dll, const char* wanted_name) {
    DWORD peoff, import_rva;
    BYTE* nt;
    BYTE* opt;
    BYTE* desc;

    if (!base || *(WORD*)base != 0x5A4D) return (void**)0;
    peoff = *(DWORD*)(base + 0x3C);
    nt = base + peoff;
    if (*(DWORD*)nt != 0x00004550u) return (void**)0;
    opt = nt + 24;
    if (*(WORD*)opt != 0x010Bu) return (void**)0;

    import_rva = *(DWORD*)(opt + 104);
    if (!import_rva) return (void**)0;

    desc = base + import_rva;
    for (;;) {
        DWORD oft = *(DWORD*)(desc + 0);
        DWORD name_rva = *(DWORD*)(desc + 12);
        DWORD ft = *(DWORD*)(desc + 16);
        DWORD* names;
        DWORD* iat;
        unsigned int i;
        const char* dllname;

        if (oft == 0 && name_rva == 0 && ft == 0) break;
        if (!name_rva || !ft) { desc += 20; continue; }

        dllname = (const char*)(base + name_rva);
        if (!str_ieq(dllname, wanted_dll)) { desc += 20; continue; }
        names = (DWORD*)(base + (oft ? oft : ft));
        iat = (DWORD*)(base + ft);
        for (i = 0; names[i] != 0; ++i) {
            DWORD v = names[i];
            if ((v & IMAGE_ORDINAL_FLAG32) == 0) {
                const char* fn = (const char*)(base + v + 2); /* skip Hint */
                if (str_ieq(fn, wanted_name)) return (void**)&iat[i];
            }
        }
        return (void**)0;
    }
    return (void**)0;
}

static int find_text_section(BYTE* base, BYTE** start_out, DWORD* size_out) {
    DWORD peoff;
    BYTE* nt;
    WORD nsec, optsz;
    BYTE* sec;
    unsigned int i;

    if (!base || *(WORD*)base != 0x5A4D) return 0;
    peoff = *(DWORD*)(base + 0x3C);
    nt = base + peoff;
    if (*(DWORD*)nt != 0x00004550u) return 0;
    nsec = *(WORD*)(nt + 6);
    optsz = *(WORD*)(nt + 20);
    sec = nt + 24 + optsz;

    for (i = 0; i < nsec; ++i, sec += 40) {
        /* Match .text */
        if (sec[0]=='.' && sec[1]=='t' && sec[2]=='e' && sec[3]=='x' &&
            sec[4]=='t' && sec[5]==0) {
            DWORD vsize = *(DWORD*)(sec + 8);
            DWORD va = *(DWORD*)(sec + 12);
            if (!vsize || !va) return 0;
            *start_out = base + va;
            *size_out = vsize;
            return 1;
        }
    }
    return 0;
}

/*
 * Signature common to these three MMF 1.x builds:
 *
 *   52                       push edx          ; destination buffer
 *   6A 00                    push 0
 *   8D 3C 80                 lea edi,[eax+eax*4]
 *   68 C4 00 00 00           push 0C4h         ; EM_GETLINE
 *   8B 81 9C 00 00 00        mov eax,[ecx+9Ch]
 *   66 89 32                 mov [edx],si      ; EM_GETLINE capacity word
 *   8B 84 07 FC 40 FD FF     mov eax,[edi+eax-2BF04h]
 *   50                       push eax          ; HWND
 *   FF 15 xx xx xx xx        call [SendMessageA IAT]
 *
 * Only the absolute IAT operand is wildcarded. The candidate is accepted only
 * if that operand equals the USER32!SendMessageA IAT slot found by
 * parsing the host import table, only one match is required.
 */
static int locate_buggy_call(BYTE* base, SendMessageA_t* send_slot, BYTE** return_out) {
    static const BYTE sig[30] = {
        0x52,0x6A,0x00,0x8D,0x3C,0x80,0x68,0xC4,0x00,0x00,
        0x00,0x8B,0x81,0x9C,0x00,0x00,0x00,0x66,0x89,0x32,
        0x8B,0x84,0x07,0xFC,0x40,0xFD,0xFF,0x50,0xFF,0x15
    };
    BYTE* text;
    DWORD size;
    DWORD i, j;
    BYTE* found = (BYTE*)0;
    unsigned int count = 0;

    if (!find_text_section(base, &text, &size)) return 0;
    if (size < 34) return 0;

    for (i = 0; i <= size - 34; ++i) {
        BYTE* p = text + i;
        for (j = 0; j < 30; ++j) {
            if (p[j] != sig[j]) break;
        }
        if (j != 30) continue;
        if (*(DWORD*)(p + 30) != (DWORD)send_slot) continue;
        ++count;
        found = p;
        if (count > 1) return 0;
    }

    if (count != 1 || !found) return 0;
    *return_out = found + 34; /* instruction immediately after CALL [IAT] */
    return 1;
}

static int pin_self(BYTE* host) {
    void** gmfn_slot = find_iat_slot(host, "KERNEL32.dll", "GetModuleFileNameA");
    void** load_slot = find_iat_slot(host, "KERNEL32.dll", "LoadLibraryA");
    GetModuleFileNameA_t gmfn;
    LoadLibraryA_t loadlib;
    char path[520];
    DWORD n;

    if (!gmfn_slot || !load_slot) return 0;
    gmfn = *(GetModuleFileNameA_t*)gmfn_slot;
    loadlib = *(LoadLibraryA_t*)load_slot;
    if (!gmfn || !loadlib) return 0;

    n = gmfn((HMODULE)g_self, path, (DWORD)sizeof(path));
    if (n == 0 || n >= (DWORD)sizeof(path)) return 0;
    path[n] = 0;
    return loadlib(path) != (HMODULE)0;
}

static LRESULT WINAPI FixedSendMessageA(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    BYTE* caller = (BYTE*)_ReturnAddress();
    WORD capacity = 0;
    int should_fix = 0;
    LRESULT result;

    if (msg == EM_GETLINE && lp != 0 && caller == g_bug_return) {
        capacity = *(volatile WORD*)(DWORD)lp;
        should_fix = 1;
    }

    result = g_real_SendMessageA(hwnd, msg, wp, lp);

    /* EM_GETLINE does not append a terminator. MMF 1.x immediately treats the
       returned buffer as a C string. Add the missing terminator only at the
       one validated buggy call site, and only when there is space. */
    if (should_fix && result >= 0 && (DWORD)result < (DWORD)capacity) {
        ((volatile char*)(DWORD)lp)[result] = '\0';
    }
    return result;
}

static int install_fix(void) {
    BYTE* base = process_image_base();
    void** send_any;
    void** vp_any;
    SendMessageA_t* send_slot;
    VirtualProtect_t vp;
    BYTE* bug_return;
    DWORD old_protect = 0, ignored = 0;

    if (g_installed) return 1;
    if (!base) return 0;

    send_any = find_iat_slot(base, "USER32.dll", "SendMessageA");
    vp_any = find_iat_slot(base, "KERNEL32.dll", "VirtualProtect");
    if (!send_any || !vp_any) return 0;

    send_slot = (SendMessageA_t*)send_any;
    vp = *(VirtualProtect_t*)vp_any;
    if (!*send_slot || !vp) return 0;

    if (!locate_buggy_call(base, send_slot, &bug_return)) return 0;

    /* Keep the COX mapped for the rest of the editor process before putting a
       function pointer into MMF's IAT. This deliberately adds one module ref. */
    if (!g_pinned) {
        if (!pin_self(base)) return 0;
        g_pinned = 1;
    }

    g_host_base = base;
    g_bug_return = bug_return;
    g_send_slot = send_slot;
    g_real_SendMessageA = *send_slot;

    if (!vp((LPVOID)send_slot, (DWORD)sizeof(*send_slot), PAGE_READWRITE, &old_protect)) {
        g_real_SendMessageA = (SendMessageA_t)0;
        g_send_slot = (SendMessageA_t*)0;
        g_bug_return = (BYTE*)0;
        return 0;
    }

    *send_slot = FixedSendMessageA;
    vp((LPVOID)send_slot, (DWORD)sizeof(*send_slot), old_protect, &ignored);
    g_installed = 1;
    return 1;
}

/* MMF COX ABI */

int WINAPI DllMain(HINSTANCE hinst, DWORD reason, LPVOID reserved) {
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) g_self = hinst;
    return TRUE;
}

DWORD WINAPI GetInfos(int info) {
    if (info == KGI_VERSION) return EXT_VERSION2;
    return 0;
}

/* Called once by the MMF frame editor for an extension. */
int WINAPI Initialize(void* mv, int quiet) {
    (void)mv; (void)quiet;
    /* Fail open. Returning success keeps the extension harmless on an unknown
       MMF build, so the patch isn't installed. */
    install_fix();
    return 0;
}

int WINAPI Free(void* mv)
{
    (void)mv;
    /* Intentionally don't unhook, pin_self keeps the module resident until
       process termination, avoiding a dangling IAT pointer during shutdown. */
    return 0;
}

/* MMF interfaces */
void WINAPI DefaultOI(void* a, void* b) { (void)a;(void)b; }
int WINAPI LoadObject(void* a,const char* b,void* c,int d){(void)a;(void)b;(void)c;(void)d;return 0;}
void WINAPI UnloadObject(void* a,void* b,int c){(void)a;(void)b;(void)c;}
void WINAPI PutObject(void* a,void* b,void* c,USHORT d){(void)a;(void)b;(void)c;(void)d;}
void WINAPI RemoveObject(void* a,void* b,void* c,USHORT d){(void)a;(void)b;(void)c;(void)d;}
int WINAPI MakeIcon(void* a,void* b,char* c,void* d,void* e){(void)a;(void)b;(void)c;(void)d;(void)e;return 0;}
void WINAPI AppendPopup(void* a,HMENU b,void* c,void* d,int e){(void)a;(void)b;(void)c;(void)d;(void)e;}
int WINAPI SelectPopup(void* a,int b,void* c,void* d,void* e,USHORT* f,int g){(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;return 0;}
int WINAPI CreateObject(void* a,void* b,void* c){(void)a;(void)b;(void)c;return TRUE;}
int WINAPI ModifyObject(void* a,void* b,void* c,void* d,int e,USHORT* f){(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;return 0;}
int WINAPI RebuildExt(void* a,void* b,BYTE* c,void* d,void* e,USHORT* f){(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;return 0;}
void WINAPI EndModifyObject(void* a,int b,USHORT* c){(void)a;(void)b;(void)c;}
void WINAPI GetObjectRect(void* a,void* b,void* c,void* d){(void)a;(void)b;(void)c;(void)d;}
void WINAPI EditorDisplay(void* a,void* b,void* c,void* d,void* e){(void)a;(void)b;(void)c;(void)d;(void)e;}
BOOL WINAPI IsTransparent(void* a,void* b,void* c,int d,int e){(void)a;(void)b;(void)c;(void)d;(void)e;return FALSE;}
void WINAPI PrepareToWriteObject(void* a,void* b,void* c){(void)a;(void)b;(void)c;}
void WINAPI UpdateFileNames(void* a,char* b,void* c,void* d){(void)a;(void)b;(void)c;(void)d;}
int WINAPI EnumElts(void* a,void* b,void* c,void* d,LPARAM e,LPARAM f){(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;return 0;}
BOOL WINAPI UsesFile(char* a){(void)a;return FALSE;}
void WINAPI CreateFromFile(char* a,void* b){(void)a;(void)b;}
void WINAPI GetObjInfos(void* a,void* b,char* name,char* author,char* copyright,char* comment,char* http) {
    (void)a;(void)b;
    copy_text(name,"MMF 1.x Compatibility Fix");
    copy_text(author,"Joshtek");
    copy_text(copyright,"");
    copy_text(comment,"Fixes problem with MMF editor on modern Windows, inserting into CCA is not necessary.");
    copy_text(http,"");
}

short WINAPI CreateRunObject(void* a,void* b,void* c){(void)a;(void)b;(void)c;return 0;}
short WINAPI DestroyRunObject(void* a,LONG b){(void)a;(void)b;return 0;}
short WINAPI HandleRunObject(void* a){(void)a;return 0;}
short WINAPI DisplayRunObject(void* a){(void)a;return 0;}
short WINAPI ReInitRunObject(void* a){(void)a;return 0;}
short WINAPI PauseRunObject(void* a){(void)a;return 0;}
short WINAPI ContinueRunObject(void* a){(void)a;return 0;}
short WINAPI GetRunObjectInfos(void* a,void* b){(void)a;(void)b;return 0;}

HMENU WINAPI GetConditionMenu(void* a,void* b,void* c){(void)a;(void)b;(void)c;return (HMENU)0;}
HMENU WINAPI GetActionMenu(void* a,void* b,void* c){(void)a;(void)b;(void)c;return (HMENU)0;}
HMENU WINAPI GetExpressionMenu(void* a,void* b,void* c){(void)a;(void)b;(void)c;return (HMENU)0;}
short WINAPI GetConditionCodeFromMenu(void* a,short b){(void)a;(void)b;return -1;}
short WINAPI GetActionCodeFromMenu(void* a,short b){(void)a;(void)b;return -1;}
short WINAPI GetExpressionCodeFromMenu(void* a,short b){(void)a;(void)b;return -1;}
void WINAPI GetConditionString(void* a,short b,char* c,short d){(void)a;(void)b;(void)d;if(c)c[0]=0;}
void WINAPI GetActionString(void* a,short b,char* c,short d){(void)a;(void)b;(void)d;if(c)c[0]=0;}
void WINAPI GetExpressionString(void* a,short b,char* c,short d){(void)a;(void)b;(void)d;if(c)c[0]=0;}
void WINAPI GetConditionTitle(void* a,short b,short c,char* d,short e){(void)a;(void)b;(void)c;(void)e;if(d)d[0]=0;}
void WINAPI GetActionTitle(void* a,short b,short c,char* d,short e){(void)a;(void)b;(void)c;(void)e;if(d)d[0]=0;}
void WINAPI GetExpressionTitle(void* a,short b,char* c,short d){(void)a;(void)b;(void)d;if(c)c[0]=0;}
void* WINAPI GetConditionInfos(void* a,short b){(void)a;(void)b;return (void*)0;}
void* WINAPI GetActionInfos(void* a,short b){(void)a;(void)b;return (void*)0;}
void* WINAPI GetExpressionInfos(void* a,short b){(void)a;(void)b;return (void*)0;}
HGLOBAL WINAPI UpdateEditStructure(void* a,void* b){(void)a;(void)b;return (HGLOBAL)0;}
USHORT WINAPI GetRunObjectDataSize(void* a,void* b){(void)a;(void)b;return 0;}
